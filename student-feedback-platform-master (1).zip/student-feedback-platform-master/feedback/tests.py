from django.test import TestCase

# Create your tests here.

# login as 'student' and try to access 'view-feedback-faculty' from url box
# login as 'faculty' and try to access 'submit-feedback' and 'view-feedback' from url box
# try to access above pages as 'admin'

# don't register Feedback model in admin site

# what happens to student's feedbacks if the student is deleted
# what happens to feedbacks when course is deleted