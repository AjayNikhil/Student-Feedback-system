from django.test import TestCase

# Create your tests here.

# what if staffRecord or emailRecord is deleted,
# what if the student moves to next semester,