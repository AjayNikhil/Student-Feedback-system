# student-feedback-platform
A web application built using Django to serve as a student feedback platform.
